"""The mapping loop shared by the live runner and the offline simulator.

1. sweep every route of length <= depth  (identities of all depth<=2 hosts)
2. round-based probing until all 20 hosts are known and every warp is pinned
3. as soon as the observations admit exactly one network, stop walking
"""
import time
from collections import Counter
import net, probe, solver


def build(fam):
    n = net.Net(dict(fam))
    try:
        n.refine()
    except ValueError:
        n = net.Net(dict(fam))
    return n


def sweep(e, log=print):
    """depth-2 in full, then depth-3 only under routes whose host is still open"""
    import itertools
    for r in itertools.product(net.WARPS, repeat=2):
        if r not in e.fam:
            if not e.walk(r):
                return None
    e.save()
    n = build(e.fam)
    log("depth-2 done: %s moves=%s" % (n.stats(), e.i.moves))
    todo = [r for r in itertools.product(net.WARPS, repeat=2)]
    skipped = 0
    while True:
        rest = [r for r in todo
                if n.simulate(r) is None
                and any(r + (y,) not in e.fam for y in net.WARPS)]
        if not rest:
            break
        r = rest[0]
        for y in net.WARPS:
            if r + (y,) not in e.fam:
                if not e.walk(r + (y,)):
                    return None
        e.save()
        n = build(e.fam)
    for r in todo:
        if any(r + (y,) not in e.fam for y in net.WARPS):
            skipped += 1
    log("depth-3 done: %s moves=%s (skipped %d subtrees)" % (n.stats(), e.i.moves, skipped))
    return n


def enumerate_sols(n, limit, tlimit, shuffle=False):
    s = solver.Solver(n)
    return s, s.solve(limit=limit, tlimit=tlimit, shuffle=shuffle,
                      node_limit=3000000)


def host_at(st, r):
    h = 0
    for w in r:
        h = st["adj"][(h, w)]
    return h


def choose_probe(sols, fam, budget):
    """walk that splits the surviving networks fastest per move spent."""
    N = len(sols)
    pos = {}
    for r in fam:
        if len(r) > 5:
            continue
        try:
            pos[r] = [host_at(st, r) for st in sols]
        except KeyError:
            pass
    best = None
    for r, hs in pos.items():
        for y in net.WARPS:
            if r + (y,) in fam or len(r) + 1 > budget:
                continue
            outs = Counter(st["fam"][st["adj"][(hs[k], y)]] for k, st in enumerate(sols))
            resid = sum((v / N) ** 2 for v in outs.values())
            gain = (1.0 - resid) / (len(r) + 1)
            if gain > 0:
                sc = (-gain, len(r) + 1)
                if best is None or sc < best[0]:
                    best = (sc, r + (y,))
    return best[1] if best else None


def map_network(e, depth=3, tbudget=2400, log=print, uniq_tl=20, hybrid=True):
    t0 = time.time()
    n = sweep(e, log)
    if n is None:
        log("sweep aborted")
        n = build(e.fam)
    probes = 0
    status = "complete"
    checked_at = -1
    while True:
        if not n.missing() and not n.unresolved():
            break
        if not n.missing() and len(n.unresolved()) <= 30 and probes != checked_at:
            checked_at = probes
            s, sols = enumerate_sols(n, limit=2, tlimit=uniq_tl)
            if len(sols) == 1 and not s.stop():
                log("network already unique with %d edges open" % len(n.unresolved()))
                n.unique = sols[0]
                break
            if len(sols) == 0 and not s.stop():
                log("!! observations are contradictory")
                status = "contradiction"
                break
        if e.i.moves < 3:
            status = "out_of_moves"
            break
        if time.time() - t0 > tbudget:
            status = "timeout"
            break
        r = None
        if hybrid and not n.missing():
            s, sols = enumerate_sols(n, limit=120, tlimit=25, shuffle=True)
            if len(sols) > 1:
                r = choose_probe(sols, e.fam, e.i.moves - 1)
        if r is None:
            r = probe.pick_greedy(n, e.i.moves - 1)
        if r is None:
            status = "no_probe"
            break
        e.walk(r)
        e.save()
        probes += 1
        n = build(e.fam)
        if probes % 10 == 0:
            log("  [%4ds] probes=%d moves=%s %s open=%d" % (
                time.time() - t0, probes, e.i.moves, n.stats(), len(n.unresolved())))
    log("mapping %s: probes=%d moves_left=%s %s" % (status, probes, e.i.moves, n.stats()))
    return n, status
