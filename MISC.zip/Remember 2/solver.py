"""Exact enumeration of every network consistent with what we observed.

Variables : adj[(host, warp)] -> host
Constraints:
  * the family seen through warp w of a host is fixed by its signature
  * every observed route must replay to the family we saw at its end
  * 20 hosts, each with 5 distinct neighbours, warps are two-way
Undiscovered hosts are introduced in first-use order so solutions are canonical.
"""
import sys, random, time
from net import Net, WARPS, NHOSTS


class Solver:
    def __init__(self, net):
        self.n = net
        self.fam = net.fam
        self.nknown = len(net.hosts)
        # host table: fam + sig, extended with placeholders for missing hosts
        self.base_fam = [h["fam"] for h in net.hosts] + [None] * net.missing()
        self.base_sig = [list(h["sig"]) for h in net.hosts] + \
                        [[None] * 5 for _ in range(net.missing())]
        # evidence: (h,w) -> {y: family}
        self.ev = {}
        for h in range(self.nknown):
            for w in WARPS:
                e = net.evidence(h, w)
                if e:
                    self.ev[(h, w)] = e
        self.routes = net.routes

    # ------------------------------------------------------------------
    def solve(self, limit=200000, node_limit=4000000, shuffle=False, tlimit=None):
        self.sols = []
        self.nodes = 0
        self.limit = limit
        self.node_limit = node_limit
        self.shuffle = shuffle
        self.deadline = (time.time() + tlimit) if tlimit else None
        st = {
            "adj": dict(self.n.adj),
            "fam": list(self.base_fam),
            "sig": [list(s) for s in self.base_sig],
            "used": self.nknown,
        }
        self._search(st)
        return self.sols

    # ---- helpers ------------------------------------------------------
    def nbrs(self, adj, h):
        out = set()
        for w in WARPS:
            t = adj.get((h, w))
            if t is not None:
                out.add(t)
        for (a, w), t in adj.items():
            if t == h:
                out.add(a)
        return out

    def cands(self, st, h, w):
        adj, fam, sig = st["adj"], st["fam"], st["sig"]
        want = sig[h][w - 1]
        taken = {adj[(h, ww)] for ww in WARPS if (h, ww) in adj and ww != w}
        ev = self.ev.get((h, w), {})
        out = []
        upper = st["used"] + (1 if st["used"] < NHOSTS else 0)
        for t in range(upper):
            if t == h or t in taken:
                continue
            if want is not None and fam[t] is not None and fam[t] != want:
                continue
            if t >= st["used"]:            # a fresh host
                if want is None:
                    continue               # family of a new host must be known
            nb = self.nbrs(adj, t)
            if h not in nb and len(nb) >= 5:
                continue
            ok = True
            for y, f in ev.items():
                s = sig[t][y - 1]
                if s is not None and s != f:
                    ok = False
                    break
            if not ok:
                continue
            back = [ww for ww in WARPS
                    if (sig[t][ww - 1] in (None, fam[h]))
                    and adj.get((t, ww), h) == h]
            if not back:
                continue
            out.append(t)
        return out

    def assign(self, st, h, w, t):
        """returns a new state or None on contradiction"""
        adj = dict(st["adj"])
        fam = list(st["fam"])
        sig = [list(s) for s in st["sig"]]
        used = st["used"]
        adj[(h, w)] = t
        if t >= used:
            used = t + 1
            fam[t] = sig[h][w - 1]
        for y, f in self.ev.get((h, w), {}).items():
            if sig[t][y - 1] is None:
                sig[t][y - 1] = f
            elif sig[t][y - 1] != f:
                return None
        return {"adj": adj, "fam": fam, "sig": sig, "used": used}

    def propagate(self, st):
        changed = True
        while changed:
            changed = False
            adj, sig, fam = st["adj"], st["sig"], st["fam"]
            for h in range(st["used"]):
                for w in WARPS:
                    if (h, w) in adj:
                        continue
                    c = self.cands(st, h, w)
                    if not c:
                        return None
                    if len(c) == 1:
                        st = self.assign(st, h, w, c[0])
                        if st is None:
                            return None
                        changed = True
            adj, sig, fam = st["adj"], st["sig"], st["fam"]
            pairs = {(t, a) for (a, w), t in adj.items()}
            for (t, a) in pairs:
                if any(adj.get((t, w)) == a for w in WARPS):
                    continue
                cand = [w for w in WARPS if (t, w) not in adj
                        and sig[t][w - 1] in (None, fam[a])]
                if not cand:
                    return None
                if len(cand) == 1:
                    st = self.assign(st, t, cand[0], a)
                    if st is None:
                        return None
                    changed = True
        return st

    def unassigned(self, st):
        return [(h, w) for h in range(st["used"]) for w in WARPS
                if (h, w) not in st["adj"]]

    # ---- search -------------------------------------------------------
    def stop(self):
        return (len(self.sols) >= self.limit or self.nodes > self.node_limit
                or (self.deadline and time.time() > self.deadline))

    def _search(self, st):
        if self.stop():
            return
        self.nodes += 1
        st = self.propagate(st)
        if st is None:
            return
        if st["used"] < NHOSTS:
            un = self.unassigned(st)
        else:
            un = self.unassigned(st)
        if not un:
            if st["used"] != NHOSTS:
                return
            if not self.verify(st):
                return
            self.sols.append(st)
            return
        # most constrained variable
        best, bc = None, None
        for (h, w) in un:
            c = self.cands(st, h, w)
            if bc is None or len(c) < len(bc):
                best, bc = (h, w), c
                if len(c) <= 1:
                    break
        if not bc:
            return
        if self.shuffle:
            random.shuffle(bc)
        for t in bc:
            ns = self.assign(st, best[0], best[1], t)
            if ns is not None:
                self._search(ns)
            if self.stop():
                return

    def verify(self, st):
        adj, fam = st["adj"], st["fam"]
        for h in range(NHOSTS):
            nb = {adj[(h, w)] for w in WARPS}
            if len(nb) != 5 or h in nb:
                return False
            for t in nb:
                if sum(1 for w in WARPS if adj[(t, w)] == h) != 1:
                    return False
        for r, f in self.fam.items():
            h = 0
            for w in r:
                h = adj[(h, w)]
            if fam[h] != f:
                return False
        return True


def key_of(st):
    return tuple(sorted(st["adj"].items())), tuple(st["fam"])


def predict(st, route):
    h = 0
    for w in route:
        h = st["adj"][(h, w)]
    return st["fam"][h]


def path_of(st, route):
    h = 0
    out = [st["fam"][h]]
    for w in route:
        h = st["adj"][(h, w)]
        out.append(st["fam"][h])
    return out
