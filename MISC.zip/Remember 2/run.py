"""Full live solve: sweep -> probing -> unique network -> sanity check -> flag."""
import json, os, sys, time
import mz, net, mapper, quiz
from explore import Explorer

HERE = os.path.dirname(os.path.abspath(__file__))


def main(iid=None, depth=3, tbudget=2700, submit=True):
    t0 = time.time()
    e = Explorer(iid)
    print("INSTANCE", e.i.iid, flush=True)

    def log(*a):
        print("[%4ds]" % (time.time() - t0), *a, flush=True)

    n, status = mapper.map_network(e, depth, tbudget, log=log)
    if n.conflicts:
        log("!! signature conflicts:", n.conflicts[:6])

    s, sols = mapper.enumerate_sols(n, limit=50, tlimit=120)
    log("consistent networks:", len(sols), "moves left", e.i.moves)
    if not sols:
        log("NO consistent network - not touching the quiz")
        return e, None
    st = sols[0]
    json.dump({"adj": {"%d,%d" % k: v for k, v in st["adj"].items()},
               "fam": st["fam"], "nsol": len(sols), "status": status},
              open(os.path.join(HERE, "graph_%s.json" % e.i.iid), "w"), indent=1)
    bad = [r for r, f in e.fam.items()
           if st["fam"][mapper.host_at(st, r)] != f]
    log("observations replayed wrong:", len(bad))
    if not submit:
        return e, None

    qs = e.i.questions()
    json.dump(qs, open(os.path.join(HERE, "questions_%s.json" % e.i.iid), "w"), indent=1)
    log("quiz:", quiz.stats(qs))
    ans = quiz.answers(qs, st["adj"], st["fam"])
    if len(sols) > 1:
        agree = 0
        for q in qs:
            vals = {json.dumps(quiz.answers([q], o["adj"], o["fam"])[q["id"]])
                    for o in sols}
            agree += (len(vals) == 1)
        log("questions every candidate network agrees on: %d/100" % agree)
    r = e.i.submit(ans)
    log("SUBMIT", r.status_code, r.text[:500])
    open(os.path.join(HERE, "result_%s.json" % e.i.iid), "w").write(r.text)
    return e, r.text


if __name__ == "__main__":
    iid = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] != "-" else None
    main(iid)
