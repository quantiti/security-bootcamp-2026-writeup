"""Phase B/C: turn the route->family map into host identities and edges."""
import json, os, sys, itertools
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


def load_fam(iid):
    p = os.path.join(HERE, "fam_%s.json" % iid)
    d = json.load(open(p))
    return {tuple(int(c) for c in k.split(",") if c): v for k, v in d.items()}


def sig(fam, r):
    """(own family, family reached through warp 1..5) - None if incomplete."""
    if r not in fam:
        return None
    out = [fam[r]]
    for w in range(1, 6):
        if r + (w,) not in fam:
            return None
        out.append(fam[r + (w,)])
    return tuple(out)


def build(fam, maxdepth=2):
    """Group routes of length<=maxdepth by signature -> host ids."""
    sigs = {}
    route_host = {}
    for r in sorted(fam, key=lambda x: (len(x), x)):
        if len(r) > maxdepth:
            continue
        s = sig(fam, r)
        if s is None:
            continue
        if s not in sigs:
            sigs[s] = len(sigs)
        route_host[r] = sigs[s]
    return sigs, route_host


def main(iid):
    fam = load_fam(iid)
    sigs, route_host = build(fam, 2)
    inv = {v: k for k, v in sigs.items()}
    print("distinct hosts found at depth<=2:", len(sigs))
    byhost = defaultdict(list)
    for r, h in route_host.items():
        byhost[h].append(r)
    for h in sorted(byhost):
        print("H%-2d fam=%-9s warpfams=%s routes=%s" % (
            h, inv[h][0], list(inv[h][1:]),
            [",".join(map(str, r)) or "()" for r in sorted(byhost[h], key=lambda x: (len(x), x))]))

    # directly known edges: routes r with |r|<=1  ->  r+w has |r+w|<=2
    edges = {}
    for r, h in route_host.items():
        if len(r) > 1:
            continue
        for w in range(1, 6):
            t = route_host.get(r + (w,))
            if t is None:
                continue
            if (h, w) in edges and edges[(h, w)] != t:
                print("!! conflict", h, w, edges[(h, w)], t)
            edges[(h, w)] = t
    print("directly known directed edges:", len(edges))
    known_hosts = sorted({h for (h, w) in edges})
    print("hosts with full adjacency:", known_hosts)
    return fam, sigs, route_host, edges


if __name__ == "__main__":
    main(sys.argv[1])
