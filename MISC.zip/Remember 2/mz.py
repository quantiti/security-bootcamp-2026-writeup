"""Can You Remember - core client library.

SAFETY: sample zips are never written to disk unencrypted and never executed.
We only read the inner member's size + sha256 in RAM.
"""
import io, json, os, sys, time, zipfile, hashlib
import requests

BASE = "http://103.70.12.125:26001"
HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, "sampledb.json")


def load_db():
    if os.path.exists(DB):
        return json.load(open(DB))
    return {"by_sha": {}, "by_size": {}}


def save_db(db):
    json.dump(db, open(DB, "w"), indent=1, sort_keys=True)


# size -> slug clusters carried over from flag-1 write-up (approximate)
SIZE_TABLE = [
    (3514368, "wannacry"),
    (1450500, "adylkuzz"),
    (1012736, "shamoon"),
    (677056, "hive"),
    (633856, "cerber"),
    (607232, "agenttesla"),
    (603136, "loki"),
    (563200, "trickbot"),
    (297984, "jigsaw"),
    (230912, "petya"),
    (223232, "hive"),
    (214016, "njrat"),
    (120832, "virut"),
    (74752, "zeroaccess"),
    (62464, "turla"),
    (44032, "zeroaccess"),
    (21504, "turla"),
]


def guess_by_size(sz):
    best = min(SIZE_TABLE, key=lambda t: abs(t[0] - sz))
    if abs(best[0] - sz) <= max(4000, best[0] * 0.06):
        return best[1]
    return None


class Inst:
    def __init__(self, iid=None, verbose=True):
        self.s = requests.Session()
        self.verbose = verbose
        if iid is None:
            iid = self.s.post(BASE + "/instance/start", timeout=30).json()["instance_id"]
        self.iid = iid
        self.s.headers["X-Instance-Id"] = iid
        self.moves = None
        self.hearts = None
        self.db = load_db()
        self.samples_fetched = 0

    # ---- raw api -------------------------------------------------------
    def _req(self, method, path, **kw):
        for attempt in range(4):
            try:
                r = self.s.request(method, BASE + path, timeout=60, **kw)
                if r.status_code >= 500:
                    time.sleep(1 + attempt)
                    continue
                return r
            except requests.RequestException:
                time.sleep(1 + attempt)
        raise RuntimeError("request failed %s %s" % (method, path))

    def cur(self):
        j = self._req("GET", "/host/current").json()
        self.moves = j.get("moves_remaining", self.moves)
        self.hearts = j.get("hearts", self.hearts)
        return j

    def move(self, w):
        j = self._req("POST", "/move", json={"warp": int(w)}).json()
        self.moves = j.get("moves_remaining", self.moves)
        return j

    def reset(self):
        return self._req("POST", "/reset").json()

    def classify(self, family):
        j = self._req("POST", "/host/classify", json={"family": family}).json()
        if "hearts" in j:
            self.hearts = j["hearts"]
        return j

    def questions(self):
        return self._req("POST", "/sanity-check/questions").json()

    def submit(self, answers):
        return self._req("POST", "/sanity-check/submit", json=answers)

    # ---- sample handling ----------------------------------------------
    def sample_id(self, view=None):
        """Return (size, sha256) of the inner sample at the current host,
        or None when the host is safe."""
        c = view or self.cur()
        u = c.get("sample_url")
        if not u:
            return None
        if not u.startswith("http"):
            u = BASE + u
        zb = self.s.get(u, timeout=120).content
        self.samples_fetched += 1
        zf = zipfile.ZipFile(io.BytesIO(zb))
        name = zf.namelist()[0]
        data = zf.read(name, pwd=b"infected")
        return (len(data), hashlib.sha256(data).hexdigest())

    def fam_here(self, view=None):
        """family slug at the current host ('safe' if clean, None if unknown)."""
        sid = self.sample_id(view)
        if sid is None:
            return "safe"
        sz, sha = sid
        known = self.db["by_sha"].get(sha)
        if known:
            return known
        return None


def main():
    cmd = sys.argv[1]
    if cmd == "start":
        i = Inst()
        print(i.iid)
        print(json.dumps(i.cur()))


if __name__ == "__main__":
    main()
