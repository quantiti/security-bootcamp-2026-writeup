Tôi không có tool trong ngữ cảnh này nên không tự ghi file được — dưới đây là nội dung đầy đủ để bạn lưu lại. (Agent chính vẫn đang chạy run 5 ở nền, nên phần run 5 là trạng thái đang diễn ra.)

## File 1 — `FINDINGS.md`

````markdown
# Malware Maze — Những gì đã tìm ra

## Cơ chế challenge

| Thông số | Giá trị |
|---|---|
| Hosts | 20 |
| Warps mỗi host | 5 |
| Cạnh có hướng cần map | **100** (50 vô hướng) |
| Hearts | 3 (sai 3 lần = hết) |
| Moves | 1000 |
| Thời gian sống instance | 1 giờ |
| `/reset` | **miễn phí**, không cần classify |
| Classify đúng | miễn phí, không giới hạn |

## Phát hiện cốt lõi

### 1. API KHÔNG trả về host id
`GET /host/current` chỉ có `sample_url`, `solved`, `moves_remaining`, `hearts`.
→ Phải **tự suy ra** host đang đứng. Đây là toàn bộ độ khó của bài.

### 2. Sample KHÔNG xác định host
Cả mạng chỉ có **3–6 file khác nhau** cho 20 host → nhiều host chạy malware
byte-identical. Dùng hash/fingerprint file làm identity sẽ **gộp nhầm các host
khác nhau** và tạo ra self-edge ảo.

### 3. Identity đúng = ROUTE từ start
Vì `/reset` miễn phí, một chuỗi warp từ start luôn dẫn tới đúng một host.
→ Route chính là identity chính xác.

### 4. Nhận diện host = SIGNATURE
`signature = (family của chính nó, family tại warp 1..5)`
Đây là thứ duy nhất phân biệt được 2 host chạy cùng một file.

### 5. Family PHẢI được server xác nhận
Copy family từ host khác cùng file mà không classify → **mọi câu hỏi đi qua
host đó đều sai**. Bằng chứng khớp tuyệt đối:

```
Run 2: 54 câu đi hết bằng route đã đi
       - 17 câu chạm host CHƯA xác nhận
       - 37 câu chỉ chạm host ĐÃ xác nhận
       => điểm server: 0.37
```

### 6. Chấm điểm theo TỪNG CÂU (exact match), không theo phần tử
Kiểm chứng: model "theo câu" dự đoán 37, model "theo phần tử" dự đoán 0.43.
Server trả 0.37 → chấm theo câu.

### 7. Câu hỏi có 2 loại (50/50)
| Loại | Đề bài | Đáp án |
|---|---|---|
| List | "every host you stand on" | mảng, **n+1 phần tử**, host start đứng đầu |
| Single | "the host where you stop" | **một chuỗi slug** |

Gửi sai kiểu = 0 điểm dù family đúng. Run 1 gửi toàn list → 50 câu tự động sai.

### 8. Route dài là all-or-nothing
Câu hỏi dài tới **29–30 warps**. Chỉ cần 1 cạnh sai ở bất kỳ đâu là cả câu sai.
→ Với flag 2 (99%), **độ chính xác của cạnh quan trọng hơn số lượng cạnh**.

### 9. Replay route KHÔNG phát hiện được cạnh sai
Run 4: graph replay 236/236 route đã đi không lỗi, nhưng vẫn có ≥4 cạnh sai
(chỉ lộ ra ở route dài). Route đã đi hầu hết depth ≤4 nên không chạm cạnh sai.

**Cách phát hiện đúng — luật hai chiều:**
- Mỗi host có đúng 5 hàng xóm **khác nhau**
- Nếu `X --w--> Y` thì Y có **đúng một** warp quay lại X
- Family tại warp w của X phải khớp family thật của Y

Run 4 vi phạm 8 lần → graph sai, mà replay không thấy.

### 10. Cửa một chiều
`POST /sanity-check/questions` **chấm dứt vĩnh viễn** việc di chuyển.
Tổng số warp của cả 100 câu ≈ **746 < 1000 moves** → nếu đọc đề trước rồi mới đi
thì đạt 100% dễ dàng. Đó chính là lý do luật cấm. Phải map **mù**.

## An toàn khi xử lý mẫu
- File zip giữ nguyên mật khẩu trên đĩa, **không bao giờ chạy**
- Chỉ `analyze` giải mã **trong RAM** để đọc strings + PE header
- Fingerprint lấy từ central directory (size + CRC32) — không cần mật khẩu
````

## File 2 — `RUNS.md`

````markdown
# Lịch sử các lần chạy

| Run | Instance | Điểm | Flag | Nguyên nhân chính |
|---|---|---|---|---|
| 1 | 17d3d346 | 0.35 | — | Identity theo sample + sai kiểu đáp án |
| 2 | 71502e3b | 0.37 | — | Family chưa được server xác nhận |
| 3 | 735097e4 | **0.72** | **Flag 1** | Xác nhận khi tới nơi |
| 4 | 038ea673 | 0.68 | Flag 1 | Early-abort 2 warp → cạnh sai |
| 5 | 3ce0d883 | đang chạy | — | Guarded + CSP |

**Flag 1:** `SBC{f2a9f90d8257a6c9682e0402d220ac6c}`

## Run 1 — 0.35
Ba lỗi chồng nhau:
1. Identity theo fingerprint file → 2 host adylkuzz bị gộp, sinh self-edge ảo
2. `look` tạo node trùng mỗi lần gọi trên safe host
3. Gửi toàn bộ 100 câu dạng list → 50 câu single tự động sai

## Run 2 — 0.37
Đã sửa kiểu đáp án. 18/20 host, nhưng chỉ **76/241** host malware được xác nhận.
165 host là ngõ cụt, family chỉ copy từ file trùng → mọi câu chạm chúng đều sai.

## Run 3 — 0.72 → FLAG 1
Sửa gốc: **classify ngay khi tới nơi** thay vì suy đoán.
- 219/222 host được server xác nhận (so với 76/241)
- 18/20 host, 40/100 cạnh, **24.6 moves/cạnh**
- Sàn an toàn 54 câu, thực tế 72

## Run 4 — 0.68 (thấp hơn dù map tốt gấp đôi)
Áp dụng early-abort: chấp nhận khi partial signature khớp duy nhất sau **2 warp**.
- 90/100 cạnh, **10.3 moves/cạnh** (nhanh gấp 2.4 lần)
- **NHƯNG ≥4 cạnh sai chứng minh được** (8 vi phạm luật hai chiều)
- Câu ngắn (≤4 warp): ~68/70 đúng
- Câu dài (>4 warp): **~0/30 đúng**

Bài học: tối ưu nhầm đại lượng. Số cạnh tăng nhưng độ tin cậy giảm.

## Malware đã gặp
| Family | SHA256 (đầu) | Dấu hiệu nhận biết |
|---|---|---|
| wannacry | `ed01ebfb...` / `49762141...` | 3514368 bytes, giả `diskpart.exe`, chuỗi WNcry |
| azorult | `31850d46...` / `64ebc22f...` | C2 `http://ravor.ac.ug` |
| adylkuzz | `8200755c...` | 1450500 bytes |
| petya | `26b4699a...` / `ab79506b...` | 230912 bytes, native PE |
| jigsaw | `f056be80...` | .NET + `http://btc.blockr.io/api/v1/` |
| agenttesla | `a46fa149...` | .NET, version info giả "Atlas Realty / StoreSim" |
| hive | `f81637eb...` | 677056 bytes, packed, không có string |
| loki, turla | (run 2) | chưa ghi hash |

**Lưu ý:** slug viết thường, không dấu phân cách (`agenttesla`, không `agent-tesla`).
````

## File 3 — `PLAN.md`

````markdown
# Kế hoạch & thuật toán

## Quy trình chuẩn
```
python maze.py start
python maze.py mapedges          # tự map, dừng khi gặp mẫu lạ
python maze.py name <route> <slug>
python maze.py complete          # suy luận cạnh còn thiếu bằng CSP
python maze.py quiz confirm      # CỬA MỘT CHIỀU
python maze.py answers
python maze.py submit confirm
```

## Thuật toán hiện tại

**1. Map theo CẠNH, không theo route**
Sweep theo route tốn 5^depth và phần lớn là đi lại host đã biết.
Map theo cạnh: với mỗi host đã nhận diện, giải từng cạnh (host, warp) → host.

**2. Nhận diện có bảo vệ (guarded identify)**
- Đi từng warp con một, so partial signature với các host đã biết
- Chỉ chấp nhận khi khớp **duy nhất và đã đủ 4 warp** (run 4 dùng 2 warp → sai)
- Nếu không khớp host nào → chắc chắn là host mới → lấy đủ signature

**3. Cổng kiểm tra trực tiếp (live gate)**
Sau mỗi lần gán cạnh, kiểm tra luật hai chiều. Vi phạm → bỏ suy đoán, đi hết
5 warp lấy signature đầy đủ.

**4. Hoàn thiện bằng CSP (`complete`)**
Ràng buộc: 5 hàng xóm khác nhau + signature cố định family mỗi warp +
đúng một warp quay lại. Chỉ lưu khi nghiệm **DUY NHẤT** và
tái tạo đúng 100% route đã đi và 0 vi phạm.

## Chi phí đo được
| Phương pháp | moves/cạnh | Cạnh đạt được | Độ tin cậy |
|---|---|---|---|
| Sweep theo depth (run 3) | 24.6 | 40 | cao |
| Early-abort 2 warp (run 4) | 10.3 | 90 | **có cạnh sai** |
| Guarded 4 warp (run 5) | ~13.6 | ~73 dự kiến | đang kiểm chứng |
| Lý thuyết tối thiểu | ~1 | 100 | — |

## Vấn đề chưa giải quyết (chặn Flag 2)

**Ngân sách moves.** 13.6 × 100 = 1360 > 1000.
→ CSP phải suy ra khoảng 30 cạnh cuối. Nếu CSP mơ hồ thì không đủ.

**Cải tiến chưa làm — điều hướng không reset (DFS):**
- Hiện tại mỗi lần đi đều `/reset` rồi đi lại từ start → tốn `depth` moves cho
  **1 thông tin**
- Warp là hai chiều: sau khi `X --w--> Y`, có đúng 1 warp ở Y quay lại X.
  Tìm được nó một lần → đi lại X↔Y chỉ tốn **2 moves mãi mãi**
- Đường kính mạng chỉ ~2 (bậc 5, 20 đỉnh) → điều hướng rất rẻ
- Ước tính **300–400 moves cho toàn bộ map** thay vì 984
- **Rủi ro:** dò warp quay lại làm ta đi xa X, nếu lạc thì chi phí phục hồi có
  thể ăn hết phần tiết kiệm → chưa dám làm

**Suy luận hai chiều đơn thuần không hiệu quả:** ở mật độ 40% chỉ thêm được
đúng 1 cạnh. Chỉ hữu ích khi host đã biết 4/5 cạnh.

## Nguyên tắc rút ra
1. **Không bao giờ đoán family** — sai 1 lần mất 1 heart trong 3
2. **Không bao giờ tin dữ liệu chưa được server xác nhận**
3. **Đo bằng "host đã xác nhận", không phải "route đã đi"**
4. **Kiểm tra graph bằng luật hai chiều**, không chỉ replay route
5. `quiz` là cửa một chiều — chỉ gọi khi đã map xong
````