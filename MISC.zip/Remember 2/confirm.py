"""Confirm family slugs against the server oracle on a throw-away instance.

usage: confirm.py <iid> <warp> <slug>[,<slug>...]
Walks entry -> warp, then tries each slug until one is accepted.
"""
import sys, json
import mz

iid = sys.argv[1]
route = [int(x) for x in sys.argv[2].split(",") if x]
cands = sys.argv[3].split(",")

i = mz.Inst(iid)
i.reset()
for w in route:
    c = i.cur()
    if c.get("sample_url"):
        sid = i.sample_id(c)
        fam = i.db["by_sha"].get(sid[1])
        if not fam:
            print("blocked: unknown family on the way at", sid)
            sys.exit(1)
        print("  unlock", fam, i.classify(fam))
    i.move(w)

c = i.cur()
sid = i.sample_id(c)
if sid is None:
    print("host is safe")
    sys.exit(0)
sz, sha = sid
print("host sample size=%d sha=%s" % (sz, sha))
for cand in cands:
    r = i.classify(cand)
    print("   %-14s -> %s" % (cand, json.dumps(r)))
    if r.get("correct"):
        i.db["by_sha"][sha] = cand
        i.db["by_size"][str(sz)] = cand
        mz.save_db(i.db)
        print("CONFIRMED", sha[:16], "=", cand)
        break
    if r.get("hearts", 1) <= 0:
        print("out of hearts")
        break
