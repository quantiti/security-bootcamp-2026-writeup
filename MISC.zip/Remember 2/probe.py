"""Probe picking: build partial signatures of the hosts behind unknown warps.

Round based - every unresolved warp gets one extra observation before any of
them gets a second one, so undiscovered hosts surface as early as possible.
"""
from collections import Counter
import net
from net import WARPS, NEW


def pick_greedy(n, budget=10 ** 9):
    best = None
    for (h, w) in n.unresolved():
        if not n.routes[h]:
            continue
        cand = n.candidates(h, w)
        if len(cand) == 1 and cand[0] != NEW:
            continue                      # propagation will take it
        if not cand:
            continue
        ev = n.evidence(h, w)
        free = [y for y in WARPS if y not in ev]
        if not free:
            continue
        r = n.canon(h)
        cost = len(r) + 2
        if cost > budget:
            continue
        real = [t for t in cand if t != NEW]
        by = None
        for y in free:
            g = Counter(n.hosts[t]["sig"][y - 1] for t in real)
            worst = max(g.values()) if g else 0
            sc = (worst, -len(g), y)
            if by is None or sc < by[0]:
                by = (sc, y)
        newonly = 1 if (len(cand) == 1 and cand[0] == NEW) else 2
        key = (newonly, len(ev), cost, -len(cand))
        if best is None or key < best[0]:
            best = (key, r + (w, by[1]))
    return best[1] if best else None
