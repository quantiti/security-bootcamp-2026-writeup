"""Reconnaissance on a throw-away instance: enumerate the depth-1 sample pool."""
import json, sys
import mz

i = mz.Inst()
print("instance", i.iid)
c = i.cur()
print("entry:", json.dumps(c))

seen = {}
for w in range(1, 6):
    i.reset()
    i.move(w)
    c = i.cur()
    sid = i.sample_id(c)
    print("warp", w, "->", "safe" if sid is None else sid, "moves_left", i.moves)
    if sid:
        seen.setdefault(sid, []).append(w)

print()
print("distinct samples at depth 1:")
for (sz, sha), ws in seen.items():
    print("  size=%-9d sha=%s warps=%s guess=%s known=%s" % (
        sz, sha[:16], ws, mz.guess_by_size(sz), i.db["by_sha"].get(sha)))
print("iid", i.iid)
