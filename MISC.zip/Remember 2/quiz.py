"""Turn a solved network into quiz answers."""
import re, json


def route_of(q):
    return tuple(int(m) for m in re.findall(r"warp (\d)", q["route_map"]))


def is_list(q):
    return "every host" in q["question"]


def answers(qs, adj, fams):
    out = {}
    for q in qs:
        r = route_of(q)
        h = 0
        path = [fams[h]]
        for w in r:
            h = adj[(h, w)]
            path.append(fams[h])
        out[q["id"]] = path if is_list(q) else path[-1]
    return out


def stats(qs):
    ls = [len(route_of(q)) for q in qs]
    return {"n": len(qs), "total_warps": sum(ls), "max": max(ls), "min": min(ls),
            "list_qs": sum(1 for q in qs if is_list(q))}
