"""Phase A: walk every route of length <= DEPTH from the entry host and record
the malware family standing on each prefix.

usage: explore.py [instance_id] [depth]
Writes fam_<iid>.json  ->  {"1,2,3": "loki", ...}
"""
import itertools, json, os, sys, time
import mz

HERE = os.path.dirname(os.path.abspath(__file__))


class Explorer:
    def __init__(self, iid=None):
        self.i = mz.Inst(iid)
        self.fam = {}          # route tuple -> slug
        self.route_sha = {}    # route tuple -> sha256 of the sample seen there
        self.ziplen2sha = {}   # zip content-length -> sha256 (per pool, global)
        self.path = os.path.join(HERE, "fam_%s.json" % self.i.iid)
        p2 = os.path.join(HERE, "ziplen.json")
        if os.path.exists(p2):
            self.ziplen2sha = json.load(open(p2))
        self.zpath = p2
        if os.path.exists(self.path):
            self.fam = {tuple(int(c) for c in k.split(",") if c): v
                        for k, v in json.load(open(self.path)).items()}
        self.fam[()] = "safe"

    def save(self):
        json.dump({",".join(map(str, k)): v for k, v in self.fam.items()},
                  open(self.path, "w"), indent=0, sort_keys=True)
        json.dump(self.ziplen2sha, open(self.zpath, "w"), indent=1)

    # --- family of the host we are standing on, given the /move view -----
    def observe(self, view, route=None):
        u = view.get("sample_url")
        if not u:
            return "safe"
        url = mz.BASE + u
        n = self.i.s.head(url, timeout=60).headers["content-length"]
        sha = self.ziplen2sha.get(n)
        if sha is None:
            sz, sha = self.i.sample_id(view)
            self.ziplen2sha[n] = sha
            print("   [new sample] ziplen=%s size=%d sha=%s guess=%s" % (
                n, sz, sha[:16], mz.guess_by_size(sz)), flush=True)
            db = self.i.db
            db.setdefault("size_by_sha", {})[sha] = sz
            if sha not in db["by_sha"]:
                db["by_sha"][sha] = mz.guess_by_size(sz)   # provisional
            mz.save_db(db)
            self.save()
        if route is not None:
            self.route_sha[route] = sha
        return self.i.db["by_sha"].get(sha)

    def alternates(self, sha, tried):
        sz = self.i.db.get("size_by_sha", {}).get(sha)
        if sz is None:
            return []
        order = sorted(mz.SIZE_TABLE, key=lambda t: abs(t[0] - sz))
        out = []
        for _, slug in order:
            if slug not in tried and slug not in out:
                out.append(slug)
        return out[:3]

    def unlock(self, fam, route):
        """classify the current host; returns True when movement is unlocked."""
        if fam == "safe":
            return True
        sha = self.route_sha.get(route)
        tried = []
        if fam is not None:
            r = self.i.classify(fam)
            if r.get("correct"):
                if sha and self.i.db["by_sha"].get(sha) != fam:
                    self.i.db["by_sha"][sha] = fam
                    mz.save_db(self.i.db)
                return True
            tried.append(fam)
            print("!! wrong family '%s' at %s hearts=%s" % (fam, route, r.get("hearts")),
                  flush=True)
        if sha is None:
            return False
        for cand in self.alternates(sha, tried):
            if self.i.hearts is not None and self.i.hearts <= 1:
                print("!! out of spare hearts, stopping", flush=True)
                return False
            r = self.i.classify(cand)
            print("   retry '%s' -> %s" % (cand, r), flush=True)
            tried.append(cand)
            if r.get("correct"):
                self.i.db["by_sha"][sha] = cand
                mz.save_db(self.i.db)
                self.relabel(sha, cand)
                return True
        return False

    def relabel(self, sha, slug):
        """a provisional guess turned out wrong - fix every route we recorded"""
        for rt, s in self.route_sha.items():
            if s == sha:
                self.fam[rt] = slug
        self.save()

    def walk(self, route):
        """reset then walk `route`; records fam for every prefix."""
        self.i.reset()
        cur = ()
        for w in route:
            f = self.fam.get(cur)
            if f is None:
                raise RuntimeError("prefix unknown " + str(cur))
            if not self.unlock(f, cur):
                return False
            view = self.i.move(w)
            cur = cur + (w,)
            if cur not in self.fam or cur not in self.route_sha:
                f = self.observe(view, cur)
                self.fam[cur] = f
        if self.fam.get(cur) is None:
            # a sample we have never named: let the server tell us
            if not self.unlock(None, cur):
                print("!! could not name the sample at", cur, flush=True)
                return False
        return True

    def run(self, depth):
        t0 = time.time()
        routes = [r for r in itertools.product(range(1, 6), repeat=depth)]
        done = 0
        for r in routes:
            if r in self.fam and all(r[:k] in self.fam for k in range(depth + 1)):
                continue
            ok = self.walk(r)
            done += 1
            if not ok:
                print("ABORT at", r)
                self.save()
                return False
            if done % 10 == 0:
                self.save()
                print("%3d/%d routes  moves_left=%s hearts=%s  %.0fs" % (
                    done, len(routes), self.i.moves, self.i.hearts, time.time() - t0))
        self.save()
        print("phase A done. moves_left=%s hearts=%s elapsed=%.0fs" % (
            self.i.moves, self.i.hearts, time.time() - t0))
        return True


if __name__ == "__main__":
    iid = sys.argv[1] if len(sys.argv) > 1 else None
    depth = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    e = Explorer(iid)
    print("instance", e.i.iid)
    e.run(depth)
    print("iid", e.i.iid)
