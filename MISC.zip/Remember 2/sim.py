"""Offline simulator: random 5-regular network, same algorithm, count moves."""
import random, sys, time, itertools
import net, solver, run as R


def make_net(rng, fams=("safe", "loki", "adylkuzz", "turla"),
             weights=(4, 5, 7, 4)):
    while True:
        # configuration model on 20 nodes of degree 5
        stubs = [v for v in range(20) for _ in range(5)]
        rng.shuffle(stubs)
        edges = set()
        ok = True
        for i in range(0, len(stubs), 2):
            a, b = stubs[i], stubs[i + 1]
            if a == b or (min(a, b), max(a, b)) in edges:
                ok = False
                break
            edges.add((min(a, b), max(a, b)))
        if not ok:
            continue
        inc = {v: [] for v in range(20)}
        for a, b in edges:
            inc[a].append(b)
            inc[b].append(a)
        if any(len(v) != 5 for v in inc.values()):
            continue
        adj = {}
        for v in range(20):
            per = inc[v][:]
            rng.shuffle(per)
            for i, t in enumerate(per):
                adj[(v, i + 1)] = t
        fam = [None] * 20
        pool = []
        for f, w in zip(fams, weights):
            pool += [f] * w
        rng.shuffle(pool)
        fam = pool[:20]
        fam[0] = "safe"
        return adj, fam


class FakeInst:
    def __init__(self):
        self.moves = 1000
        self.hearts = 3


class FakeExplorer:
    def __init__(self, adj, tfam):
        self.tadj, self.tfam = adj, tfam
        self.fam = {(): tfam[0]}
        self.i = FakeInst()

    def save(self):
        pass

    def walk(self, route):
        h, cur = 0, ()
        for w in route:
            if self.i.moves <= 0:
                return False
            self.i.moves -= 1
            h = self.tadj[(h, w)]
            cur = cur + (w,)
            self.fam[cur] = self.tfam[h]
        return True

    def run(self, depth):
        for r in itertools.product(range(1, 6), repeat=depth):
            if not self.walk(r):
                return False
        return True


def trial(seed, depth=3, tbudget=600, verbose=False):
    import mapper
    rng = random.Random(seed)
    adj, tfam = make_net(rng)
    e = FakeExplorer(adj, tfam)
    t0 = time.time()
    quiet = (lambda *a: None) if not verbose else print
    n, status = mapper.map_network(e, depth, tbudget, log=quiet)
    used = 1000 - e.i.moves
    s, sols = mapper.enumerate_sols(n, limit=3, tlimit=60)
    correct = _match(sols[0], adj, tfam) if sols else None
    print("seed=%-4d hosts=%-3d moves=%-4d %-13s sols=%-2d exact=%s %.0fs"
          % (seed, len(n.hosts), used, status, len(sols), correct,
             time.time() - t0), flush=True)
    return used, status, correct


def _match(st, adj, tfam):
    """does the reconstructed graph reproduce the true one (up to relabel)?"""
    for r in itertools.product(range(1, 6), repeat=4):
        h, th = 0, 0
        for w in r:
            h = st["adj"][(h, w)]
            th = adj[(th, w)]
        if st["fam"][h] != tfam[th]:
            return False
    return True


if __name__ == "__main__":
    a = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    b = int(sys.argv[2]) if len(sys.argv) > 2 else a + 3
    for s in range(a, b):
        trial(s, verbose="-v" in sys.argv)
