"""Host identity + adjacency reconstruction for "Can You Remember".

A host is identified by its signature: (own family, family seen through warp 1..5).
Routes of length <= 2 get a full signature for free from the depth-3 sweep;
deeper routes are pinned down with targeted depth-4 probes.

Host id -1 is the sentinel "some host we have not discovered yet".
"""
import json
from collections import defaultdict

NHOSTS = 20
WARPS = (1, 2, 3, 4, 5)
NEW = -1


class Net:
    def __init__(self, fam):
        self.fam = fam                   # route tuple -> slug
        self.hosts = []                  # {fam, sig[5]}
        self.routes = defaultdict(list)  # host -> [routes]
        self.adj = {}                    # (host, warp) -> host
        self.build_known()

    # ------------------------------------------------------------------
    def sig_of(self, r):
        return [self.fam.get(r + (w,)) for w in WARPS]

    def add_host(self, fam, sig, route=None):
        self.hosts.append({"fam": fam, "sig": list(sig)})
        h = len(self.hosts) - 1
        if route is not None:
            self.routes[h].append(route)
        return h

    def build_known(self):
        """Any route whose five follow-up families are all observed carries a
        full signature and therefore identifies a host."""
        seen = {}
        self.conflicts = []
        for r in sorted(self.fam, key=lambda x: (len(x), x)):
            sig = self.sig_of(r)
            if any(s is None for s in sig):
                continue
            key = (self.fam[r], tuple(sig))
            if key not in seen:
                seen[key] = self.add_host(self.fam[r], sig)
            self.routes[seen[key]].append(r)
        rh = {}
        for h, rs in self.routes.items():
            for r in rs:
                rh[r] = h
        self.rh = rh
        for r, h in rh.items():
            for w in WARPS:
                t = rh.get(r + (w,))
                if t is None:
                    continue
                if self.adj.get((h, w), t) != t:
                    self.conflicts.append((h, w, self.adj[(h, w)], t))
                self.adj[(h, w)] = t

    def evidence(self, h, w):
        """observed family behind warp y of the (still unnamed) host at (h,w)."""
        ev = {}
        for r in self.routes[h]:
            for y in WARPS:
                f = self.fam.get(r + (w, y))
                if f is not None:
                    ev[y] = f
        return ev

    # ------------------------------------------------------------------
    def canon(self, h):
        return sorted(self.routes[h], key=lambda x: (len(x), x))[0]

    def neighbours(self, h):
        out = set()
        for w in WARPS:
            t = self.adj.get((h, w))
            if t is not None and t != NEW:
                out.add(t)
        for (a, w), t in self.adj.items():
            if t == h:
                out.add(a)
        return out

    def full(self, h):
        """True when every neighbour slot of h is accounted for."""
        return len(self.neighbours(h)) >= 5

    def warp_of(self, h, t):
        for w in WARPS:
            if self.adj.get((h, w)) == t:
                return w
        return None

    def missing(self):
        return NHOSTS - len(self.hosts)

    # ------------------------------------------------------------------
    def candidates(self, h, w):
        want = self.hosts[h]["sig"][w - 1]
        taken = {self.adj[(h, ww)] for ww in WARPS if (h, ww) in self.adj and ww != w}
        ev = self.evidence(h, w)
        out = []
        for t in range(len(self.hosts)):
            if t == h or t in taken:
                continue
            if want is not None and self.hosts[t]["fam"] != want:
                continue
            if any(self.hosts[t]["sig"][y - 1] not in (None, f) for y, f in ev.items()):
                continue
            nb_t = self.neighbours(t)
            if h not in nb_t and len(nb_t) >= 5:
                continue
            sig_t = self.hosts[t]["sig"]
            back = [ww for ww in WARPS
                    if (sig_t[ww - 1] is None or sig_t[ww - 1] == self.hosts[h]["fam"])
                    and self.adj.get((t, ww), h) == h]
            if not back:
                continue
            out.append(t)
        if self.missing() > 0 and not self.full(h):
            out.append(NEW)
        return out

    def propagate(self, verbose=False):
        changed = True
        while changed:
            changed = False
            for h in range(len(self.hosts)):
                for w in WARPS:
                    if (h, w) in self.adj:
                        continue
                    c = self.candidates(h, w)
                    if len(c) == 0:
                        raise ValueError("no candidate for (H%d,w%d)" % (h, w))
                    if len(c) == 1 and c[0] != NEW:
                        self.adj[(h, w)] = c[0]
                        changed = True
                        if verbose:
                            print("   fwd  H%d w%d -> H%d" % (h, w, c[0]))
            pairs = {(t, a) for (a, w), t in self.adj.items() if t != NEW}
            for (t, a) in pairs:
                if self.warp_of(t, a) is not None:
                    continue
                sig_t = self.hosts[t]["sig"]
                cand = [w for w in WARPS if (t, w) not in self.adj
                        and (sig_t[w - 1] is None or sig_t[w - 1] == self.hosts[a]["fam"])]
                if len(cand) == 0:
                    raise ValueError("no return warp H%d -> H%d" % (t, a))
                if len(cand) == 1:
                    self.adj[(t, cand[0])] = a
                    changed = True
                    if verbose:
                        print("   back H%d w%d -> H%d" % (t, cand[0], a))

    def refine(self):
        """propagate, then hand every route whose whole path is known to its
        host, which in turn yields more edges and more evidence."""
        while True:
            self.propagate()
            added = False
            for r in list(self.fam):
                p = self.simulate(r)
                if p is None:
                    continue
                h = p[-1]
                if r not in self.routes[h]:
                    self.routes[h].append(r)
                    added = True
            if not added:
                return
            rh = {}
            for h, rs in self.routes.items():
                for r in rs:
                    rh[r] = h
            for r, h in rh.items():
                for w in WARPS:
                    t = rh.get(r + (w,))
                    if t is None:
                        continue
                    if self.adj.get((h, w), t) != t:
                        self.conflicts.append((h, w, self.adj[(h, w)], t))
                    self.adj[(h, w)] = t

    # ------------------------------------------------------------------
    def unresolved(self):
        return [(h, w) for h in range(len(self.hosts)) for w in WARPS
                if (h, w) not in self.adj]

    def stats(self):
        return "hosts=%d/%d edges=%d/%d" % (
            len(self.hosts), NHOSTS, len(self.adj), NHOSTS * 5)

    # ------------------------------------------------------------------
    def simulate(self, route):
        """follow a warp route from the entry host; returns list of host ids
        (entry first) or None when it runs into an unknown edge."""
        h = 0
        out = [h]
        for w in route:
            t = self.adj.get((h, w))
            if t is None or t == NEW:
                return None
            h = t
            out.append(h)
        return out

    def check_routes(self):
        """every recorded observation must be reproduced by the graph."""
        bad = []
        for r, f in self.fam.items():
            path = self.simulate(r)
            if path is None:
                continue
            if self.hosts[path[-1]]["fam"] != f:
                bad.append((r, f, self.hosts[path[-1]]["fam"]))
        return bad


def load_fam(path):
    d = json.load(open(path))
    return {tuple(int(c) for c in k.split(",") if c): v for k, v in d.items()}
